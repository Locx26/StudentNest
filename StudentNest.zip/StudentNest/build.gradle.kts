// Project-level build.gradle.kts
plugins {
    // Android Application and Library Plugins
    id("com.android.application") version "8.2.1" apply false
    id("com.android.library") version "8.2.1" apply false

    // Kotlin Plugin
    id("org.jetbrains.kotlin.android") version "1.9.22" apply false

    // Hilt Dependency Injection Plugin
    id("com.google.dagger.hilt.android") version "2.50" apply false

    // Google Services Plugin (Updated to 4.4.4)
    id("com.google.gms.google-services") version "4.4.4" apply false
}