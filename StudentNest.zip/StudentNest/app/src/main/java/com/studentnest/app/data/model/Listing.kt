package com.studentnest.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "listings")
data class Listing(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val title: String,
    val location: String,
    val price: Double,
    val type: String,
    val amenities: String,
    val availabilityDate: String,
    val depositAmount: Double,
    val imageUrl: String,
    val latitude: Double,
    val longitude: Double,

    // THESE TWO FIELDS MUST BE HERE FOR THE DAO TO WORK
    val isReserved: Boolean = false,
    val reservedByUserId: Int? = null
) : Serializable