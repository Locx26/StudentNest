package com.studentnest.app.data.di

import android.content.Context
import com.studentnest.app.data.dao.ListingDao
import com.studentnest.app.data.database.AppDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AppDatabase {
        // This uses your existing getInstance logic
        return AppDatabase.getInstance(context)
    }

    @Provides
    fun provideListingDao(db: AppDatabase): ListingDao {
        return db.listingDao()
    }
}