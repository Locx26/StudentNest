package com.studentnest.app.data.database

import android.content.Context
import android.util.Log
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.studentnest.app.data.dao.UserDao
import com.studentnest.app.data.dao.ListingDao
import com.studentnest.app.data.dao.ReservationDao
import com.studentnest.app.data.model.User
import com.studentnest.app.data.model.Listing
import com.studentnest.app.data.model.Reservation
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [User::class, Listing::class, Reservation::class],
    version = 6, // Incrementing to 6 to ensure a clean slate
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun listingDao(): ListingDao
    abstract fun reservationDao(): ReservationDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "studentnest_db"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            // FIX: We cannot use INSTANCE here.
                            // We trigger seeding via a side effect or after build.
                            Log.d("AppDatabase", "Database created for the first time.")
                        }

                        override fun onOpen(db: SupportSQLiteDatabase) {
                            super.onOpen(db)
                            // This runs every time the app opens the DB
                            // We use a coroutine to check if we need to seed
                            CoroutineScope(Dispatchers.IO).launch {
                                checkAndSeedData(getInstance(context))
                            }
                        }
                    })
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private suspend fun checkAndSeedData(db: AppDatabase) {
            val dao = db.listingDao()
            // Only seed if the database is actually empty
            if (dao.getListingCount() == 0) {
                Log.d("AppDatabase", "Database empty. Seeding data...")
                populateInitialData(dao)
            }
        }

        suspend fun populateInitialData(listingDao: ListingDao) {
            try {
                val sampleListings = listOf(
                    Listing(
                        title = "Modern Single Studio",
                        location = "Village, Gaborone",
                        price = 3500.0,
                        type = "Studio",
                        amenities = "WiFi, Aircon, Parking",
                        availabilityDate = "Available Now",
                        depositAmount = 3500.0,
                        imageUrl = "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?q=80&w=1000",
                        latitude = -24.6585,
                        longitude = 25.9344,
                        isReserved = false,
                        reservedByUserId = null
                    ),
                    Listing(
                        title = "Luxury One Bedroom",
                        location = "Phakalane, Gaborone",
                        price = 5500.0,
                        type = "Apartment",
                        amenities = "Pool, Gym, Security",
                        availabilityDate = "1st June",
                        depositAmount = 5500.0,
                        imageUrl = "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?q=80&w=1000",
                        latitude = -24.5900,
                        longitude = 25.9600,
                        isReserved = false,
                        reservedByUserId = null
                    ),
                    Listing(
                        title = "Cosy Garden Cottage",
                        location = "Broadhurst, Gaborone",
                        price = 2800.0,
                        type = "Cottage",
                        amenities = "Private Garden, WiFi",
                        availabilityDate = "Available Now",
                        depositAmount = 2000.0,
                        imageUrl = "https://images.unsplash.com/photo-1493809842364-78817add7ffb?q=80&w=1000",
                        latitude = -24.6300,
                        longitude = 25.9200,
                        isReserved = false,
                        reservedByUserId = null
                    )
                )
                listingDao.insertAll(sampleListings)
                Log.d("AppDatabase", "Seeding successful!")
            } catch (e: Exception) {
                Log.e("AppDatabase", "Seeding failed: ${e.message}")
            }
        }
    }
}