package com.studentnest.app

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.studentnest.app.ui.auth.LoginActivity
import com.studentnest.app.ui.listings.ListingsActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 1. Enable modern edge-to-edge display
        enableEdgeToEdge()

        setContentView(R.layout.activity_main)

        // 2. MATCH THE ID: Apply window insets to the view with id "main"
        // This ensures your splash screen content doesn't get cut off by the status bar
        val mainView = findViewById<View>(R.id.main)
        ViewCompat.setOnApplyWindowInsetsListener(mainView) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // 3. Delay for 2 seconds to show branding
        Handler(Looper.getMainLooper()).postDelayed({
            // FIXED: Removed the <caret> marker from the string
            val prefs = getSharedPreferences("studentnest_prefs", MODE_PRIVATE)
            val userId = prefs.getInt("userId", -1)

            val targetActivity = if (userId != -1) {
                ListingsActivity::class.java
            } else {
                LoginActivity::class.java
            }

            startActivity(Intent(this, targetActivity))

            // 4. Professional Fade Transition
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }, 2000)
    }
}