package com.studentnest.app.ui.listings

import android.content.Intent
import android.os.Bundle
import android.view.HapticFeedbackConstants
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.studentnest.app.R
import com.studentnest.app.data.database.AppDatabase
import com.studentnest.app.data.model.Reservation
import com.studentnest.app.databinding.ActivityListingDetailBinding
import com.studentnest.app.ui.maps.MapsActivity
import com.studentnest.app.ui.reservation.ReservationActivity
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class ListingDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityListingDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityListingDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val listingId = intent.getIntExtra("listingId", -1)
        val prefs = getSharedPreferences("studentnest_prefs", MODE_PRIVATE)
        val userId = prefs.getInt("userId", -1)
        val db = AppDatabase.getInstance(this)

        lifecycleScope.launch {
            // Fetch listing from DB
            val listing = db.listingDao().getListingById(listingId) ?: return@launch

            // 1. PROFESSIONAL IMAGE LOADING (Glide)
            Glide.with(this@ListingDetailActivity)
                .load(listing.imageUrl)
                .placeholder(android.R.drawable.ic_menu_gallery)
                .error(android.R.drawable.ic_menu_report_image)
                .centerCrop()
                .into(binding.ivDetailImage)

            // 2. PROFESSIONAL STRING FORMATTING (From strings.xml)
            binding.tvDetailTitle.text = listing.title
            binding.tvDetailLocation.text = listing.location
            binding.tvDetailPrice.text = getString(R.string.currency_format, listing.price)
            binding.tvDetailAmenities.text = "Amenities: ${listing.amenities}"
            binding.tvDetailDeposit.text = "Deposit Required: " + getString(R.string.currency_format, listing.depositAmount)
            binding.tvDetailDate.text = "Available From: ${listing.availabilityDate}"

            if (listing.isReserved) {
                binding.btnPayDeposit.text = getString(R.string.status_occupied)
                binding.btnPayDeposit.isEnabled = false
                binding.btnReserve.isEnabled = false
            }

            // 3. PAY DEPOSIT LOGIC
            binding.btnPayDeposit.setOnClickListener { view ->
                // Haptic Feedback (Physical pulse)
                view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)

                if (userId == -1) {
                    Toast.makeText(this@ListingDetailActivity, "Please login first", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                processReservation(db, listing, userId)
            }

            // 4. RESERVE NOW LOGIC (Haptic Included)
            binding.btnReserve.setOnClickListener { view ->
                view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)

                if (userId == -1) {
                    Toast.makeText(this@ListingDetailActivity, "Please login first", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                processReservation(db, listing, userId)
            }

            // 5. MAP LOGIC
            binding.btnViewOnMap.setOnClickListener {
                val mapIntent = Intent(this@ListingDetailActivity, MapsActivity::class.java)
                mapIntent.putExtra("lat", listing.latitude)
                mapIntent.putExtra("lng", listing.longitude)
                mapIntent.putExtra("title", listing.title)
                startActivity(mapIntent)
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            }
        }
    }

    private fun processReservation(db: AppDatabase, listing: com.studentnest.app.data.model.Listing, userId: Int) {
        lifecycleScope.launch {
            try {
                // Mark listing as reserved
                db.listingDao().reserveListing(listing.id, userId)

                // Generate Reference Number
                val dateStr = SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date())
                val ref = "SN-$dateStr-${listing.id.toString().padStart(4, '0')}"

                // Create Reservation Record
                val reservation = Reservation(
                    userId = userId,
                    listingId = listing.id,
                    referenceNumber = ref,
                    paymentDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                )
                db.reservationDao().insertReservation(reservation)

                // Navigate to Success
                val successIntent = Intent(this@ListingDetailActivity, ReservationActivity::class.java)
                successIntent.putExtra("ref", ref)
                successIntent.putExtra("title", listing.title)
                successIntent.putExtra("deposit", listing.depositAmount)
                startActivity(successIntent)

                finish()
            } catch (e: Exception) {
                Toast.makeText(this@ListingDetailActivity, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
}