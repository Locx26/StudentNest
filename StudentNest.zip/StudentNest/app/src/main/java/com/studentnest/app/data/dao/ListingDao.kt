package com.studentnest.app.data.dao

import androidx.room.*
import com.studentnest.app.data.model.Listing
import kotlinx.coroutines.flow.Flow

@Dao
interface ListingDao {

    @Query("SELECT * FROM listings ORDER BY id DESC")
    fun getAllListingsAsFlow(): Flow<List<Listing>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertListing(listing: Listing)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(listings: List<Listing>)

    @Query("SELECT * FROM listings WHERE id = :id LIMIT 1")
    suspend fun getListingById(id: Int): Listing?

    @Query("SELECT * FROM listings")
    suspend fun getAllListingsOnce(): List<Listing>

    @Query("""
        SELECT * FROM listings 
        WHERE (:location = '' OR location = :location) 
        AND (price >= :min AND price <= :max)
    """)
    suspend fun getListingsByFilter(location: String, min: Double, max: Double): List<Listing>

    // This query now works because 'isReserved' and 'reservedByUserId' exist in Listing.kt
    @Query("UPDATE listings SET isReserved = 1, reservedByUserId = :userId WHERE id = :listingId")
    suspend fun reserveListing(listingId: Int, userId: Int)

    @Query("SELECT COUNT(*) FROM listings")
    suspend fun getListingCount(): Int

    @Delete
    suspend fun delete(listing: Listing)
}