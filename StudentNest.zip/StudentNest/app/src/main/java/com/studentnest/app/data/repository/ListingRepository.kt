package com.studentnest.app.data.repository

import com.studentnest.app.data.dao.ListingDao
import com.studentnest.app.data.model.Listing
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton // Makes sure one repository is shared across the app
class ListingRepository @Inject constructor(
    private val listingDao: ListingDao
) {
    // Used for the main list (Flow allows real-time updates from Room)
    val allListings: Flow<List<Listing>> = listingDao.getAllListingsAsFlow()

    // Used for the search/filter feature
    suspend fun filterListings(location: String, min: Double, max: Double): List<Listing> {
        return listingDao.getListingsByFilter(location, min, max)
    }

    /**
     * NEW: Used by the DetailViewModel to show a specific house.
     * Hilt will now be able to provide this data to your DetailFragment.
     */
    suspend fun getListingById(id: Int): Listing? {
        return listingDao.getListingById(id)
    }
}
