package com.studentnest.app.ui.listings

import androidx.lifecycle.*
import com.studentnest.app.data.model.Listing
import com.studentnest.app.data.repository.ListingRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

// This annotation tells Hilt how to provide this ViewModel to your Activity
@HiltViewModel
class ListingViewModel @Inject constructor(
    private val repository: ListingRepository
) : ViewModel() {

    private val _listings = MutableLiveData<List<Listing>>()
    val listings: LiveData<List<Listing>> get() = _listings

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> get() = _isLoading

    init {
        loadAllListings()
    }

    fun loadAllListings() {
        _isLoading.value = true
        viewModelScope.launch {
            // Collecting the database Flow from our Repository
            repository.allListings.collect { list ->
                _listings.value = list
                _isLoading.value = false
            }
        }
    }

    fun applyFilters(location: String, minPrice: Double, maxPrice: Double) {
        _isLoading.value = true
        viewModelScope.launch {
            val filteredList = repository.filterListings(location, minPrice, maxPrice)
            _listings.value = filteredList
            _isLoading.value = false
        }
    }
}
