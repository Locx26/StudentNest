package com.studentnest.app.ui.listings

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.studentnest.app.databinding.ActivityListingsBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint // REQUIRED: This allows Hilt to inject dependencies into the Fragments inside this Activity
class ListingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityListingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 1. Setup View Binding
        binding = ActivityListingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // 2. Implementation Note:
        // You do not need to manually load the Fragment here.
        // The FragmentContainerView in your activity_listings.xml
        // automatically loads the 'startDestination' defined in your nav_graph.xml.
    }

    /**
     * Professional Touch: Handles the 'Up' button (back arrow in the toolbar)
     * automatically for all Fragments.
     */
    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}