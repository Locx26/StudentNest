package com.studentnest.app.utils

import com.studentnest.app.data.dao.ListingDao
import com.studentnest.app.data.dao.UserDao
import com.studentnest.app.data.model.Listing
import com.studentnest.app.data.model.User
import com.studentnest.app.R

object DataSeeder {

    suspend fun seedIfEmpty(userDao: UserDao, listingDao: ListingDao) {
        if (userDao.getUserCount() == 0) {
            seedUsers(userDao)
        }
        if (listingDao.getListingCount() == 0) {
            seedListings(listingDao)
        }
    }

    private suspend fun seedUsers(dao: UserDao) {
        val users = (1..50).map { i ->
            val n = i.toString().padStart(2, '0')
            User(
                fullName = "Student$n",
                email = "student$n@studentnest.bw",
                password = "Pass1234",
                role = "Student"
            )
        }
        users.forEach {
            dao.insertUser(it)
        }
    }

    private suspend fun seedListings(dao: ListingDao) {
        val areas = listOf(
            Triple("Village", -24.6580, 25.9080),
            Triple("Broadhurst", -24.6780, 25.9120),
            Triple("Gaborone West", -24.6550, 25.8850),
            Triple("Mogoditshane", -24.5980, 25.8600),
            Triple("Block 8", -24.6700, 25.9300)
        )

        val types = listOf("Single Room", "Bachelor Flat", "1-Bedroom", "2-Bedroom", "Studio")

        val amenities = listOf(
            "WiFi, Water, Electricity",
            "Water, Electricity, Parking",
            "WiFi, Water, Electricity, Parking, Security",
            "Water, Electricity",
            "WiFi, Water, Electricity, DSTV"
        )

        val listings = mutableListOf<Listing>()
        var count = 1

        areas.forEach { (area, lat, lng) ->
            repeat(10) { i ->
                val price = (800 + (i * 150) + (count * 10)).toDouble()
                listings.add(
                    Listing(
                        title = "${types[i % 5]} in $area #$count",
                        price = price,
                        location = area,
                        type = types[i % 5],
                        amenities = amenities[i % 5],
                        availabilityDate = "2026-0${(i % 6) + 1}-01",
                        depositAmount = price,
                        // UPDATED: Changed imageResId to imageUrl and converted to String
                        imageUrl = "android.resource://com.studentnest.app/" + R.drawable.ic_launcher_background,
                        latitude = lat + (i * 0.001),
                        longitude = lng + (i * 0.001)
                    )
                )
                count++
            }
        }
        dao.insertAll(listings)
    }
}