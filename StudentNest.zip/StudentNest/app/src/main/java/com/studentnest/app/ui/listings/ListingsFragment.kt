package com.studentnest.app.ui.listings

import android.os.Bundle
import android.view.View
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.studentnest.app.R
import com.studentnest.app.data.model.Listing
import com.studentnest.app.databinding.FragmentListingsBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ListingsFragment : Fragment(R.layout.fragment_listings) {

    private var _binding: FragmentListingsBinding? = null
    private val binding get() = _binding!!

    private val viewModel: ListingViewModel by viewModels()
    private lateinit var adapter: ListingsAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = FragmentListingsBinding.bind(view)

        setupRecyclerView()
        setupClickListeners()
        observeData()
        handleFilterResults() // New professional way to get results back
    }

    /**
     * INDUSTRY STANDARD: Using SavedStateHandle to receive data back
     * from FilterFragment without using Activity Intents.
     */
    private fun handleFilterResults() {
        val navBackStackEntry = findNavController().currentBackStackEntry
        navBackStackEntry?.savedStateHandle?.getLiveData<Bundle>("filter_results")
            ?.observe(viewLifecycleOwner) { bundle ->
                val location = bundle.getString("location") ?: ""
                val minPrice = bundle.getDouble("min_price", 0.0)
                val maxPrice = bundle.getDouble("max_price", 100000.0)

                viewModel.applyFilters(location, minPrice, maxPrice)

                // Clear the result so it doesn't re-apply on rotation
                navBackStackEntry.savedStateHandle.remove<Bundle>("filter_results")
            }
    }

    private fun observeData() {
        viewModel.listings.observe(viewLifecycleOwner) { listings ->
            updateUI(listings)
        }

        viewModel.isLoading.observe(viewLifecycleOwner) { isLoading ->
            showLoading(isLoading)
        }
    }

    private fun setupRecyclerView() {
        adapter = ListingsAdapter(emptyList()) { listing ->
            val bundle = bundleOf("listingId" to listing.id)
            findNavController().navigate(
                R.id.action_listingsFragment_to_detailFragment,
                bundle
            )
        }

        binding.rvListings.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = this@ListingsFragment.adapter
            setHasFixedSize(true) // Optimization for performance
        }
    }

    private fun setupClickListeners() {
        binding.fabFilter.setOnClickListener {
            findNavController().navigate(R.id.action_listingsFragment_to_filterFragment)
        }

        binding.btnClearFilter.setOnClickListener {
            viewModel.loadAllListings()
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.shimmerView.apply {
            if (isLoading) {
                startShimmer()
                visibility = View.VISIBLE
                binding.rvListings.visibility = View.GONE
            } else {
                stopShimmer()
                visibility = View.GONE
            }
        }
    }

    private fun updateUI(listings: List<Listing>) {
        val isEmpty = listings.isEmpty()
        binding.emptyState.visibility = if (isEmpty) View.VISIBLE else View.GONE
        binding.rvListings.visibility = if (isEmpty) View.GONE else View.VISIBLE

        if (!isEmpty) {
            adapter.updateData(listings)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}